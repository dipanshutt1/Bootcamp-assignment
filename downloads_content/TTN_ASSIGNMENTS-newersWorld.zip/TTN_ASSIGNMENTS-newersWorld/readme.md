ttn assingmen
