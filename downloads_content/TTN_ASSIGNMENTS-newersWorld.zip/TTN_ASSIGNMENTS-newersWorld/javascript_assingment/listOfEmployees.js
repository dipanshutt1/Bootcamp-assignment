let Employees=[
    {
        name:"bob",
        age:40,
        salary:1000,
        DOB:"2-july-1994"
        
    },
    {
        name:"foo",
        age:40,
        salary:8000,
        DOB:"2-june-1991"


    },
    {
        name:"racheal",
        age:20,
        salary:2000,
        DOB:"20-jan-1999"

    },
    {
        name:"richard",
        age:25,
        salary:900,
        DOB:"2-feb-1992"

    },
    { name:"casey",
    age:28,
    salary:700,
    DOB:"2-july-1990"}
  



]

let printAllEmployees=function(){
 Employees.forEach(emp=>console.log(emp)
 )};