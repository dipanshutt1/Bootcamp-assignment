"use strict";

let areaOfCircle=function(){


let radius=prompt("enter the radius");

let area=Math.PI* Math.pow(radius,2);
alert(area);
}